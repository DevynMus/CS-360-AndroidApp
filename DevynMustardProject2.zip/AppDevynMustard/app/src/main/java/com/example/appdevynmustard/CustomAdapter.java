package com.example.appdevynmustard;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapter extends ArrayAdapter<InventoryItem> {

    private ArrayList<InventoryItem> itemList;
    private Context context;

    public CustomAdapter(Context context, ArrayList<InventoryItem> itemList) {
        super(context, 0, itemList);
        this.context = context;
        this.itemList = itemList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.activity_main, parent, false);
        }

        // Get the current item
        InventoryItem currentItem = itemList.get(position);

        // Converting view for each variable
        TextView nameTextView = convertView.findViewById(R.id.itemNameTextView);
        TextView priceTextView = convertView.findViewById(R.id.itemPriceTextView);
        TextView countTextView = convertView.findViewById(R.id.itemCountTextView);

        nameTextView.setText(currentItem.getName());
        priceTextView.setText(String.format("%.2f", currentItem.getPrice()));
        countTextView.setText(String.valueOf(currentItem.getCount()));

        return convertView;
    }
}